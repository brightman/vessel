"""Vessel command-line client."""
