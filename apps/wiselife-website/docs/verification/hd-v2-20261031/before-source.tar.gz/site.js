(() => {
  'use strict';
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const dialog = $('#site-dialog');
  const content = $('#dialog-content');
  const menu = $('#main-nav');
  const toggle = $('.menu-toggle');
  const escape = value => String(value).replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
  const tag = text => `<span class="dialog-tag">${text}</span>`;
  const appLink = '<a class="button blue-button" href="../launch-preview/demos/iphone.html#product">Explore the iPhone demo ↗</a>';
  const footerLinks = '<div class="dialog-links"><a href="../privacy/">Privacy policy</a><a href="../terms/">Terms</a><a href="../compare-designs/">Compare designs</a></div>';
  const routes = {download:'download',video:'video',signin:'signin',pricing:'pricing',faq:'faq',privacy:'privacy-details',capture:'capture',insights:'insights',action:'action',clarity:'clarity',today:'today',work:'work',rhythm:'rhythm',remember:'remember'};
  let current = null;
  let opener = null;
  let ownsHistoryEntry = false;
  let activeMode = 'phone';
  const action = {title:'Prepare the first design draft',date:'',saved:false};
  const stories = {
    clarity:['A clearer day starts with a little context.','Return to the moments that mattered, connect ideas across your records, and choose what deserves your attention.','See your memories in the iPhone prototype. The website reads no personal records.'],
    today:['See your day, at a glance.','Bring your captured moments, activity, and next steps into one calm view. Explore the Today concept with sample records.','Energy, focus, and schedule scores in this design are illustrative. They are not measured health assessments or a claim that this dashboard has shipped.'],
    work:['Be present. Keep what matters.','A conversation becomes a record you can return to. Find decisions, revisit a useful idea, and review the next step before acting.','Recording starts and stops with you. This preview does not access the microphone.'],
    rhythm:['Find your own rhythm.','With your permission, Apple Health activity, sleep, and training records can sit alongside the moments you capture. Ask what changed, or look back on a week.','Availability depends on device support and permissions. Illustrative energy and focus scores are not medical assessments.'],
    remember:['A thought today. Something useful tomorrow.','Keep conversations, ideas, and reflections together. Ask your own records a question, then follow the answer back to the original words.','The linked prototype uses example data. No personal information is sent from this page.']
  };
  function view(type) {
    if (stories[type]) {const [title,body,note] = stories[type];return `${tag('Your life with WiseLife')}<h2 id="dialog-title">${title}</h2><p>${body}</p><div class="dialog-actions">${appLink}</div><p class="dialog-note">${note}</p>`;}
    if(type==='download') return `${tag('WiseLife · Local design preview')}<h2 id="dialog-title">Your private AI companion.</h2><p>Capture with iPhone or Apple Watch, explore your records, and take the next step on your own terms.</p><p>The App Store link is not configured in this local version. The button follows the supplied design; it does not initiate a download or purchase.</p><div class="dialog-actions">${appLink}<a class="button outline-button" href="../launch-preview/demos/watch.html">Try the Watch demo ↗</a><a class="button outline-button" href="../launch-preview/demos/mac/index.html#knowledge">Explore Mac Companion ↗</a></div><p class="dialog-note">Product artwork and launch copy are design references, not verification of App Store availability or user counts.</p>`;
    if(type==='signin') return `${tag('No account required')}<h2 id="dialog-title">You already have what you need.</h2><p>WiseLife is designed to work with your own devices. You do not need a WiseLife cloud account to keep local records and use local AI.</p><p>“Sign In” is included to reproduce the supplied design. No sign-in service is connected to this preview, and no credentials are collected.</p><div class="dialog-actions"><button class="button blue-button" data-open="download">Explore WiseLife</button><button class="button outline-button" data-open="privacy">See how privacy works</button></div>`;
    if(type==='video') return `${tag('Product walkthrough')}<h2 id="dialog-title">A day with WiseLife.</h2><video controls playsinline preload="metadata" poster="../assets/wiselife/film-poster.webp"><source src="../assets/wiselife/wiselife-walkthrough.mp4" type="video/mp4"><track kind="captions" src="../assets/wiselife/walkthrough-en.vtt" srclang="en" label="English" default></video><p class="dialog-note">27-second walkthrough of the interactive prototype. Example records; not a live device recording.</p>`;
    if(type==='pricing') return `${tag('Choose your WiseLife experience')}<h2 id="dialog-title">Your data. Your AI. Yours.</h2><div class="plan-grid"><article class="plan-card"><h3>WiseLife App</h3><p class="price">$9.99</p><p>Planned one-time App price.<br>iPhone + Apple Watch.</p></article><article class="plan-card"><h3>Mac Companion</h3><p class="price">Preview</p><p>Optional local AI models and a personal knowledge base.</p></article></div><div class="dialog-actions"><button class="button blue-button" data-open="download">Explore the apps</button></div><p class="dialog-note">Design-stage pricing, not a live offer. Final availability, pricing, and purchase terms will be confirmed at launch. This page collects no payments.</p>`;
    if(type==='privacy') return `${tag('Private by design')}<h2 id="dialog-title">Choose where your AI runs.</h2><p>Your records stay on your devices by default. Local processing does not need a WiseLife cloud account.</p><div class="privacy-tabs" role="tablist" aria-label="AI processing mode"><button id="tab-phone" role="tab" aria-controls="privacy-panel" aria-selected="true" data-mode="phone">iPhone</button><button id="tab-mac" role="tab" aria-controls="privacy-panel" aria-selected="false" tabindex="-1" data-mode="mac">Your Mac</button><button id="tab-external" role="tab" aria-controls="privacy-panel" aria-selected="false" tabindex="-1" data-mode="external">External AI</button></div><div id="privacy-panel" class="privacy-panel" role="tabpanel" aria-labelledby="tab-phone" tabindex="0"></div><p class="dialog-note">The reference page describes the local-only configuration. If you choose an external AI provider, selected content leaves your devices with your permission. iCloud backup, Apple Health, Calendar, and Reminders follow your Apple settings. There is no automatic cloud AI fallback.</p>${footerLinks}`;
    if(type==='capture') return `${tag('01 · Capture')}<h2 id="dialog-title">Let the thought stay.</h2><p>Tap to start a longer recording, or hold to capture a quick thought. With permission, activity and sleep records add context to the moments you keep.</p><div class="sample-record"><small>Example voice note · 10:30 AM</small><blockquote>“I should prepare the first design draft before our next meeting.”</blockquote></div><div class="dialog-actions"><button class="button blue-button" data-open="insights">See the insight</button><a class="button outline-button" href="../launch-preview/demos/watch.html">Try recording on Watch ↗</a></div><p class="dialog-note">“Automatic Capture” reflects the reference design. Voice recording is started by you; this website does not record audio.</p>`;
    if(type==='insights') return `${tag('02 · Insight')}<h2 id="dialog-title">Find the next useful step.</h2><div class="sample-record"><small>Based on your example voice note</small><blockquote>Prepare a first draft before the next meeting.</blockquote><button class="source-link" data-open="capture">Read the original words ↗</button></div><p>Check the source and decide whether this suggestion is right for you.</p><div class="dialog-actions"><button class="button blue-button" data-open="action">Review the suggested action</button></div>`;
    if(type==='action') return `${tag('03 · Action')}<h2 id="dialog-title">A next step you choose.</h2><p>Review the title and choose a date before adding the example reminder.</p>${action.saved?`<div class="confirmation" role="status"><strong>Added to this preview.</strong><p>${escape(action.title)}<br>${escape(action.date)}</p><p>Apple Reminders was not changed.</p></div><button class="button outline-button" data-edit-action>Edit this reminder</button>`:`<form class="action-form" id="action-form"><label for="action-title">Reminder<input id="action-title" name="title" maxlength="120" value="${escape(action.title)}" required></label><label for="action-date">Your chosen date<input id="action-date" name="date" type="date" value="${escape(action.date)}" required></label><button class="button blue-button" type="submit">Confirm in preview</button></form>`}<div class="sample-record"><small>Source: your example voice note</small><br><button class="source-link" data-open="capture">Return to the original capture ↗</button></div>`;
    if(type==='faq') return `${tag('A few helpful answers')}<h2 id="dialog-title">Made for your own life.</h2><div class="faq-list"><details open><summary>Do I need a cloud account?</summary><p>No WiseLife cloud account is needed for local records and local AI. The Sign In button reproduces the supplied visual design; it does not collect credentials.</p></details><details><summary>Does all AI processing stay on my devices?</summary><p>When you choose supported on-device models, yes. An authorized Mac can also serve models on your local network. If you deliberately configure an external AI provider, selected content is shared with that provider under your permission and its policies.</p></details><details><summary>Can I download WiseLife from this page?</summary><p>This version is a local design preview. The App Store and Mac release URLs have not been configured. Download buttons open product information and working prototypes.</p></details><details><summary>Do I need to buy new hardware?</summary><p>You can begin with iPhone. Apple Watch, Mac Companion, and EurekaRing provide optional ways to capture or process your records.</p></details><details><summary>Are the dashboard and user numbers live?</summary><p>No. Device screens and launch statements follow the supplied design reference. They do not verify released features or user counts. Energy and focus values are illustrative.</p></details><details><summary>Does this website store my data?</summary><p>No. Demo actions exist only in this page’s memory and reset on reload. No account, payment, microphone access, analytics, or form submission is connected.</p></details></div>${footerLinks}`;
    return '';
  }
  function closeMenu(){toggle.setAttribute('aria-expanded','false');menu.classList.remove('open');}
  function mode(type){
    activeMode=type;
    const data={phone:['On your iPhone','Supported local models process your records on iPhone. Model downloads may need an internet connection; your private records are not sent to WiseLife servers.'],mac:['On your authorized Mac','Mac Companion can provide local model APIs over your own network. The content needed for a request goes to the Mac you choose for local processing.'],external:['Only when you choose','Selected text leaves your devices and is sent to your configured AI provider. Permission is requested unless you have chosen to remember that permission.']};
    $$('[data-mode]').forEach(button=>{const selected=button.dataset.mode===type;button.setAttribute('aria-selected',String(selected));button.tabIndex=selected?0:-1;});
    $('#privacy-panel').setAttribute('aria-labelledby','tab-'+type);
    $('#privacy-panel').innerHTML=`<h3>${data[type][0]}</h3><p>${data[type][1]}</p>`;
  }
  function render(type){
    dialog.querySelector('video')?.pause();current=type;content.innerHTML=view(type);dialog.classList.toggle('video-mode',type==='video');if(!dialog.open)dialog.showModal();if(type==='privacy')mode(activeMode);dialog.scrollTop=0;$('#close-dialog').focus({preventScroll:true});
  }
  function open(type,source){
    if(!routes[type])return;
    closeMenu();
    if(!dialog.open){opener=source||document.activeElement;history.pushState({wiselifePreviewDialog:true},'','#'+routes[type]);ownsHistoryEntry=true;}
    else history.replaceState(history.state,'','#'+routes[type]);
    render(type);
  }
  function close(){
    if(!dialog.open)return;
    dialog.close();
    if(ownsHistoryEntry){ownsHistoryEntry=false;history.back();}
    else if(Object.values(routes).includes(location.hash.slice(1)))history.replaceState(history.state,'',location.pathname+location.search);
  }
  function syncRoute(){
    const type=Object.keys(routes).find(key=>routes[key]===location.hash.slice(1));
    if(type){if(type!==current||!dialog.open)render(type);}
    else if(dialog.open){ownsHistoryEntry=false;dialog.close();}
  }
  document.addEventListener('click',event=>{
    const trigger=event.target.closest('[data-open]');if(trigger){event.preventDefault();open(trigger.dataset.open,trigger);return;}
    if(event.target.closest('[data-edit-action]')){action.saved=false;render('action');$('#action-title').focus();}
    const tab=event.target.closest('[data-mode]');if(tab)mode(tab.dataset.mode);
  });
  toggle.addEventListener('click',()=>{const expanded=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(expanded));menu.classList.toggle('open',expanded);});
  menu.addEventListener('click',event=>{if(event.target.closest('a'))closeMenu();});
  document.addEventListener('click',event=>{if(!event.target.closest('.header'))closeMenu();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&toggle.getAttribute('aria-expanded')==='true'){closeMenu();toggle.focus();}});
  $('#close-dialog').addEventListener('click',close);
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)close();});
  dialog.addEventListener('close',()=>{dialog.querySelector('video')?.pause();current=null;if(opener?.isConnected)opener.focus({preventScroll:true});});
  dialog.addEventListener('keydown',event=>{
    const tab=event.target.closest('[data-mode]');if(!tab)return;
    const tabs=$$('[data-mode]');let index=tabs.indexOf(tab);
    if(event.key==='ArrowRight')index=(index+1)%tabs.length;else if(event.key==='ArrowLeft')index=(index+tabs.length-1)%tabs.length;else if(event.key==='Home')index=0;else if(event.key==='End')index=tabs.length-1;else return;
    event.preventDefault();mode(tabs[index].dataset.mode);tabs[index].focus();
  });
  dialog.addEventListener('input',event=>{if(event.target.id==='action-title'){action.title=event.target.value;event.target.setCustomValidity('');}if(event.target.id==='action-date')action.date=event.target.value;});
  dialog.addEventListener('submit',event=>{if(event.target.id!=='action-form')return;event.preventDefault();const title=$('#action-title');if(!title.value.trim()){title.setCustomValidity('Enter a reminder title.');title.reportValidity();return;}action.title=title.value.trim();action.saved=true;render('action');});
  window.addEventListener('popstate',syncRoute);
  window.addEventListener('hashchange',syncRoute);
  syncRoute();
})();
