# WiseLife · 设计图还原第二版

依据用户提供的 `WiseLife：你的私人 AI 生活方式平台.png` 独立实现，保留 V1 和现有首页。此版本仅用于本地设计对比，未部署。

## 预览入口

- 第二版：http://localhost:8789/design-preview-v2/
- 两版与原图对比：http://localhost:8789/compare-designs/
- 第一版：http://localhost:8789/design-preview/

在网站根目录运行 `python3 -m http.server 8789`。请保留整个网站目录，视频、产品演示和正式 favicon 复用已有 `assets/` 与 `launch-preview/` 资源。

## 实现与视觉依据

原图为 1024 × 1536px，按首屏 436px、设备生态 267px、每日概览 242px、隐私 313px、生活场景 156px、下载区 122px 划分。桌面等比缩放，最大宽度为 1600px；小于 900px 时重新编排为触屏布局。

图片来自用户设计图，通过 `scripts/extract-assets.py` 提取和清理。网页文字、链接、按钮与交互均为 HTML；设备屏幕、手写注释和装饰性图标保留原图像素。图片来源和处理范围见 [`assets/source-manifest.json`](assets/source-manifest.json)。提取脚本使用 Pillow、NumPy 和 OpenCV，可传入原图路径。

字体使用本地 Inter variable Latin 字体，许可见 `assets/inter-LICENSE.txt`；菜单等辅助 SVG 使用 Lucide，许可见 `assets/lucide-LICENSE.txt`。导航标志按本次设计图提取，favicon 使用已有正式 App 图标。运行时不请求外部字体、图片、统计或 API。

视觉对照见 [`evidence/reference-vs-local.jpg`](evidence/reference-vs-local.jpg)，标题像素边界测量见 [`evidence/typography-comparison.json`](evidence/typography-comparison.json)。区块几何位置与原图一致，但原图的栅格文字与浏览器字体抗锯齿并非逐像素相同；此测量不是整体相似度百分比。

## 可操作内容

- 产品、设备、隐私、工作方式和下载区的锚点导航。
- iPhone / Apple Watch / Mac 原型入口。
- 现有 27 秒演示视频，支持字幕、关闭暂停和焦点恢复。
- 隐私处理方式的键盘可操作选项卡。
- Capture → Insight → Action 示例，支持编辑提醒标题与日期、表单验证、确认与查看来源。
- FAQ、定价、下载与登录说明；对话框支持 Escape、外部点击、深链接、刷新以及浏览器前进后退。
- 单独的版本对比页，可切换 V1 / V2 或设计原图 / V2。

## 本地预览边界

App Store、登录、Mac 发布和支付服务没有连接。相应按钮会明确说明状态并提供可用原型。示例提醒只保存在当前页面内存中，不写入 Apple 提醒事项，不写浏览器存储，也不发送网络请求。

页面保留了用户设计图的文案，包括登录入口、用户数量描述与产品概念界面。它们并非对实际发布状态、用户规模或全部功能可用性的验证。图中隐私文案描述的是纯本地配置；如果用户自主选择外部 AI，相关文本仍会按授权发送到所配置的提供方。以上边界也在页面的对应交互中说明。

## 验证

结果与截图：[`evidence/verification.json`](evidence/verification.json)。

- 320 / 390 / 768 / 900 / 1024 / 1440 / 1920px，无横向溢出，资源加载成功。
- 各类交互、菜单、键盘操作、深链接和历史导航通过。
- 无 JS 错误、外部请求、数据提交或浏览器存储写入。
- V1 的 35 个文件与修改前 SHA-256 完全相同，清单保存在 `evidence/v1-hashes.json`。

复核：在网站根目录启动服务器后执行 `node design-preview-v2/scripts/verify.cjs`。脚本使用 Vessel 根目录已安装的 Playwright；可通过 `PLAYWRIGHT_MODULE` 指定模块路径，通过 `WISELIFE_ORIGIN` 指定预览服务器，通过 `WISELIFE_VERIFY_OUTPUT` 将新结果保存到独立目录。官网现位于 `Vessel/apps/wiselife-website/`。此检查仅针对网页，不验证 App 硬件功能或线上发布。
